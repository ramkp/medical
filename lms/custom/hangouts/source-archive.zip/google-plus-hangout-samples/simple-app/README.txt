== Hangout Apps Sample - Simple Hangout App ==

== What's Included ==

simpleHangoutApp.xml:  This file comprises the entire hangout app.

== Getting Help == 
If you somehow got here without finding the documentation, check out

http://developer.google.com/+/hangouts/getting-started 

to make this run!

If you've found a bug or have questions please visit our developer
forum:

http://groups.google.com/group/google-plus-developers


